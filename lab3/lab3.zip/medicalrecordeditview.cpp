#include "medicalrecordeditview.h"

medicalrecordeditview::medicalrecordeditview(QObject *parent)
    : QObject{parent}
{}
