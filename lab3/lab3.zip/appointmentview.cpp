#include "appointmentview.h"

appointmentview::appointmentview(QObject *parent)
    : QObject{parent}
{}
