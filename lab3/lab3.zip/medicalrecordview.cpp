#include "medicalrecordview.h"

medicalrecordview::medicalrecordview(QObject *parent)
    : QObject{parent}
{}
