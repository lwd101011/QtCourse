#include "medicineeditview.h"

medicineeditview::medicineeditview(QObject *parent)
    : QObject{parent}
{}
