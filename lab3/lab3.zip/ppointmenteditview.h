#ifndef PPOINTMENTEDITVIEW_H
#define PPOINTMENTEDITVIEW_H

#include <QObject>

class ppointmenteditview : public QObject
{
    Q_OBJECT
public:
    explicit ppointmenteditview(QObject *parent = nullptr);

signals:
};

#endif // PPOINTMENTEDITVIEW_H
