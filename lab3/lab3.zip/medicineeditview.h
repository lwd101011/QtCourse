#ifndef MEDICINEEDITVIEW_H
#define MEDICINEEDITVIEW_H

#include <QObject>

class medicineeditview : public QObject
{
    Q_OBJECT
public:
    explicit medicineeditview(QObject *parent = nullptr);

signals:
};

#endif // MEDICINEEDITVIEW_H
