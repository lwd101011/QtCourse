#include "ppointmenteditview.h"

ppointmenteditview::ppointmenteditview(QObject *parent)
    : QObject{parent}
{}
