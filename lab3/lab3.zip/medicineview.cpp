#include "medicineview.h"

medicineview::medicineview(QObject *parent)
    : QObject{parent}
{}
